# ResultTime Android App

This project wraps https://resulttime.in/ in an Android WebView.

Open the `android-app` folder in Android Studio and build the APK.
The existing website and Cloudflare Worker remain separate and are not modified by the wrapper.

The app supports JavaScript, local storage, media playback and the Android back button.
