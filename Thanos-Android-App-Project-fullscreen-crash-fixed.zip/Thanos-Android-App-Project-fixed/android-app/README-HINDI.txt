THANOS ANDROID APP PROJECT

Website: https://anmol99kumar4674-crypto.github.io/Thanos/

Features:
- Android WebView wrapper; live website loads inside the app
- Splash/launch screen
- Back button navigates back inside website
- JavaScript and DOM storage enabled for web app functionality
- Internet connection required

APK banana:
1. PC/laptop par Android Studio install karein.
2. Android Studio > Open > is extracted folder ko select karein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk par milega.

Note:
- Is ZIP mein Android project source hai, ready-made APK nahi.
- APK yahan directly compile nahi kiya gaya.
- Google Play Store par publish karne se pehle target SDK, privacy policy, app signing, and website ownership/content policies verify karein.
- App internet se live website load karti hai; website update karne par generally app content bhi update hota hai.
