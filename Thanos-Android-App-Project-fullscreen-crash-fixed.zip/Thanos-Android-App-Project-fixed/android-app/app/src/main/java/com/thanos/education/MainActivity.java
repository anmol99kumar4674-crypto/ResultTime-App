package com.thanos.education;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.view.Gravity;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;
    private ProgressBar progressBar;
    private FrameLayout root;
    private static final String HOME_URL = "https://anmol99kumar4674-crypto.github.io/Thanos/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(247, 249, 253));
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(247, 249, 253));

        // Lightweight branded splash shown while the app starts.
        TextView splash = new TextView(this);
        splash.setText("THANOS\n\nYour Learning Space");
        splash.setTextColor(Color.rgb(32, 64, 130));
        splash.setTextSize(23);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(Color.rgb(247, 249, 253));
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                if (progress >= 100) {
                    if (webView.getParent() == null) {
                        root.removeAllViews();
                        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
                    }
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // Keep HTTPS navigation inside the app; external schemes are left to Android.
                return !url.startsWith("https://") && !url.startsWith("http://");
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadDataWithBaseURL(null,
                        "<html><meta name='viewport' content='width=device-width, initial-scale=1'><body style='font-family:sans-serif;padding:28px;background:#f7f9fd;color:#24324a'><h2>Connection problem</h2><p>Thanos load nahi ho paaya. Internet check karke dobara try karein.</p><button onclick='location.reload()' style='padding:12px 18px'>Retry</button></body></html>",
                        "text/html", "UTF-8", null);
                }
            }
        });
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(HOME_URL);
        }
        // Start with splash visible; show the web page once it has loaded.
        webView.setBackgroundColor(Color.WHITE);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
