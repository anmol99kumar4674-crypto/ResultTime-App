THANOS APK — GitHub Actions

This repository ZIP uses the same workflow layout as the supplied ResultTime-App-main project.

Upload/extract these files into your GitHub repository:
- .github/workflows/build-apk.yml
- Thanos-Android-App-Project-fullscreen-crash-fixed.zip

Then open Actions > Build Thanos Android APK from ZIP > Run workflow.
When successful, download Artifact named Thanos-App-Debug.

Website embedded in the app:
https://anmol99kumar4674-crypto.github.io/Thanos/

Note: this is a GitHub Actions build package, not a compiled APK.
